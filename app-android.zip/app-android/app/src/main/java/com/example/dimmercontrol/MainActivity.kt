package com.example.dimmercontrol

import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val ipArduino = "192.168.4.1"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val slider = findViewById<SeekBar>(R.id.slider)
        val txtPorcentaje = findViewById<TextView>(R.id.txtPorcentaje)
        val txtEstado = findViewById<TextView>(R.id.txtEstado)
        val txtTiempo = findViewById<TextView>(R.id.txtTiempo)   // nuevo

        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, valor: Int, fromUser: Boolean) {
                txtPorcentaje.text = "$valor%"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                enviarPotencia(sb?.progress ?: 0, txtEstado, txtTiempo)
            }
        })
    }

    private fun enviarPotencia(valor: Int, txtEstado: TextView, txtTiempo: TextView) {
        thread {
            try {
                val inicio = System.currentTimeMillis()        // <-- marca de inicio

                val url = URL("http://$ipArduino/set?power=$valor")
                val con = url.openConnection() as HttpURLConnection
                con.requestMethod = "GET"
                con.connectTimeout = 2000
                con.readTimeout = 2000
                val codigo = con.responseCode
                con.inputStream.bufferedReader().readText()     // espera la respuesta completa
                con.disconnect()

                val tiempoMs = System.currentTimeMillis() - inicio   // <-- round-trip

                runOnUiThread {
                    txtEstado.text = if (codigo == 200) "OK ($valor%)" else "Error: $codigo"
                    txtTiempo.text = "Tiempo: $tiempoMs ms"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    txtEstado.text = "Sin conexión con el Arduino"
                    txtTiempo.text = "Tiempo: -- ms"
                }
            }
        }
    }
}